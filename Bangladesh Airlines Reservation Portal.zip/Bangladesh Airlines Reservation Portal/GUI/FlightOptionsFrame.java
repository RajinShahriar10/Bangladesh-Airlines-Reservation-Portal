package GUI;

import Classes.Flight;
import Util.FontLoader;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

public class FlightOptionsFrame extends JFrame implements ActionListener{
    JLabel mainTitle, nameLabel, passportLabel, classLabel, fareLabel;
    JTextField nameField, passportField;
    JComboBox<Flight> flightCombo;
    JButton confirmBtn, addToCartBtn;
    JRadioButton economyRadio, businessRadio;
    ButtonGroup classGroup;
    JLabel economyImageLabel, businessImageLabel;

Flight[] domesticFlights ={
    new Flight("Dhaka", "Chittagong", "08:00 AM", 3500),
    new Flight("Dhaka", "Sylhet", "10:00 AM", 3000),
    new Flight("Dhaka", "Rajshahi", "01:00 PM", 3200),
    new Flight("Dhaka", "Cox's Bazar", "06:30 AM", 4500),
    new Flight("Dhaka", "Jessore", "07:15 AM", 2800),
    new Flight("Dhaka", "Barisal", "09:00 AM", 2700),
    new Flight("Dhaka", "Saidpur", "11:30 AM", 3100),
    new Flight("Dhaka", "Chittagong", "04:00 PM", 3700),
    new Flight("Dhaka", "Sylhet", "05:45 PM", 3100),
    new Flight("Dhaka", "Rajshahi", "07:00 PM", 3300)
};


    Flight[] internationalFlights ={
        new Flight("Dhaka", "New York", "11:00 PM", 95000),
        new Flight("Dhaka", "Los Angeles", "03:00 AM", 98000),
        new Flight("Dhaka", "London", "10:00 AM", 85000),
        new Flight("Dhaka", "Paris", "01:00 PM", 87000),
        new Flight("Dhaka", "Toronto", "07:00 AM", 92000),
        new Flight("Dhaka", "Dubai", "05:00 PM", 40000),
        new Flight("Dhaka", "Doha", "08:00 AM", 35000),
        new Flight("Dhaka", "Istanbul", "06:30 PM", 70000),
        new Flight("Dhaka", "Tokyo", "04:00 AM", 90000),
        new Flight("Dhaka", "Sydney", "12:00 AM", 105000),
        new Flight("Dhaka", "Kolkata", "09:00 AM", 8000),
        new Flight("Dhaka", "Bangkok", "02:00 PM", 18000),
        new Flight("Dhaka", "Singapore", "06:00 PM", 25000)
    };

    String type;
    Flight[] selectedFlights;

    private static ArrayList<ConfirmFrame.Booking> allBookings = new ArrayList<>();

    public FlightOptionsFrame(String type){
        this.type = type;
        setTitle("Flight Options - " + type);
        setSize(500, 500);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.BLACK);

        mainTitle = new JLabel("Bangladesh Airlines Reservation Portal", SwingConstants.CENTER);
        mainTitle.setBounds(0, 10, 500, 30);
        mainTitle.setFont(FontLoader.montserratBold);
        mainTitle.setForeground(Color.WHITE);
        add(mainTitle);

        nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 60, 100, 25);
        nameLabel.setFont(FontLoader.montserratPlain);
        nameLabel.setForeground(Color.WHITE);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(150, 60, 300, 25);
        nameField.setFont(FontLoader.montserratPlain);
        add(nameField);

        passportLabel = new JLabel("Passport ID:");
        passportLabel.setBounds(50, 95, 100, 25);
        passportLabel.setFont(FontLoader.montserratPlain);
        passportLabel.setForeground(Color.WHITE);
        add(passportLabel);

        passportField = new JTextField();
        passportField.setBounds(150, 95, 300, 25);
        passportField.setFont(FontLoader.montserratPlain);
        add(passportField);

        classLabel = new JLabel("Class:");
        classLabel.setBounds(50, 130, 80, 25);
        classLabel.setFont(FontLoader.montserratPlain);
        classLabel.setForeground(Color.WHITE);
        add(classLabel);

        economyRadio = new JRadioButton("Economy");
        economyRadio.setBounds(130, 130, 100, 25);
        economyRadio.setBackground(new Color(0x5b12a9));
        economyRadio.setForeground(Color.WHITE);
        economyRadio.setFont(FontLoader.montserratPlain);
        economyRadio.setSelected(true);
        add(economyRadio);

        businessRadio = new JRadioButton("Business");
        businessRadio.setBounds(300, 130, 100, 25);
        businessRadio.setBackground(new Color(0x5b12a9));
        businessRadio.setForeground(Color.WHITE);
        businessRadio.setFont(FontLoader.montserratPlain);
        add(businessRadio);

        classGroup = new ButtonGroup();
        classGroup.add(economyRadio);
        classGroup.add(businessRadio);

        economyImageLabel = new JLabel();
        economyImageLabel.setBounds(130, 160, 80, 60);
        add(economyImageLabel);

        businessImageLabel = new JLabel();
        businessImageLabel.setBounds(300, 160, 80, 60);
        add(businessImageLabel);

        flightCombo = new JComboBox<>();
        flightCombo.setBounds(50, 230, 380, 25);
        flightCombo.setFont(FontLoader.montserratPlain);
        add(flightCombo);

        fareLabel = new JLabel("Fare: ");
        fareLabel.setBounds(50, 270, 300, 25);
        fareLabel.setFont(FontLoader.montserratPlain);
        fareLabel.setForeground(Color.WHITE);
        add(fareLabel);

        addToCartBtn = new JButton("Add to Cart");
        addToCartBtn.setBounds(90, 320, 140, 30);
        addToCartBtn.setBackground(new Color(0x5b12a9));
        addToCartBtn.setForeground(Color.WHITE);
        addToCartBtn.setFont(FontLoader.montserratPlain);
        addToCartBtn.addActionListener(this);
        add(addToCartBtn);

        confirmBtn = new JButton("Confirm");
        confirmBtn.setBounds(260, 320, 140, 30);
        confirmBtn.setBackground(new Color(0x5b12a9));
        confirmBtn.setForeground(Color.WHITE);
        confirmBtn.setFont(FontLoader.montserratPlain);
        confirmBtn.addActionListener(this);
        add(confirmBtn);

        economyRadio.addActionListener(e -> updateFlightComboItems());
        businessRadio.addActionListener(e -> updateFlightComboItems());
        flightCombo.addActionListener(e -> updateFare());

        loadAndSetImage(economyImageLabel, "Pic/economy.jpg", 60);
        loadAndSetImage(businessImageLabel, "Pic/business.jpg", 60);

        selectedFlights = type.equalsIgnoreCase("Domestic") ? domesticFlights : internationalFlights;
        updateFlightComboItems();

        setVisible(true);
    }

    private void loadAndSetImage(JLabel label, String imagePath, int targetHeight){
        try {
            BufferedImage originalImage = ImageIO.read(new File(imagePath));
            if (originalImage == null) return;
            int originalWidth = originalImage.getWidth();
            int originalHeight = originalImage.getHeight();
            int scaledWidth = (targetHeight * originalWidth) / originalHeight;
            Image scaledImage = originalImage.getScaledInstance(scaledWidth, targetHeight, Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(scaledImage);
            label.setIcon(icon);
            label.setSize(scaledWidth, targetHeight);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateFare(){
        Flight selectedFlight = (Flight) flightCombo.getSelectedItem();
        if (selectedFlight != null) {
            double fare = selectedFlight.getFare();
            fareLabel.setText("Fare: " + (int) fare + " BDT");
        }
    }

    private void updateFlightComboItems(){
        flightCombo.removeAllItems();
        for (Flight flight : selectedFlights){
            double fare = flight.getFare();
            if (businessRadio.isSelected()) fare *= 1.5;
            String displayText = flight.getFrom() + " → " + flight.getTo() + " | " + flight.getTime() + " | " + (int) fare + " BDT";
            flightCombo.addItem(new Flight(flight.getFrom(), flight.getTo(), flight.getTime(), fare) {
                @Override
                public String toString(){
                    return displayText;
                }
            });
        }
        updateFare();
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == confirmBtn || e.getSource() == addToCartBtn){
            String name = nameField.getText().trim();
            String passport = passportField.getText().trim();
            String flightClass = economyRadio.isSelected() ? "Economy" : "Business";
            Flight selectedFlight = (Flight) flightCombo.getSelectedItem();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your name.");
                return;
            }
            if (passport.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your passport ID.");
                return;
            }
            if (selectedFlight == null) return;

            ArrayList<Flight> flightList = new ArrayList<>();
            flightList.add(selectedFlight);

            ConfirmFrame.Booking newBooking = new ConfirmFrame.Booking(name, passport, flightClass, flightList);

            allBookings.add(newBooking);

            if (e.getSource() == addToCartBtn) {
                int option = JOptionPane.showConfirmDialog(this, "Booking added to cart.\nDo you want to buy another ticket?", "Add to Cart", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    new SelectionFrame();
                    this.dispose();
                } else {
                    new ConfirmFrame(allBookings);
                    this.dispose();
                }
            } else {
                new ConfirmFrame(allBookings);
                this.dispose();
            }
        }
    }
}