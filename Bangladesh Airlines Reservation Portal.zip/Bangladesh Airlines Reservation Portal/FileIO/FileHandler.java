package FileIO;

import Classes.User;
import java.io.*;

public class FileHandler {
    public static void saveBooking(User user) {
        if (user == null || user.getName() == null || user.getFlight() == null) {
            System.err.println("Invalid user or flight data. Booking not saved.");
            return;
        }

        File file = new File("Data/booking_data.txt");
        try {
            if (!file.exists()) {
                file.getParentFile().mkdirs();
                file.createNewFile();
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
            writer.write("Name: " + user.getName() + ", Flight: " + user.getFlight().toString() + "\n");
            writer.close();
            System.out.println("Booking saved successfully.");
        } catch (IOException e) {
            System.err.println("Error saving booking: " + e.getMessage());
        }
    }
}